// claude-rio "without / with" ASCII animation (option 1c) — pure frame renderer.
// Usage: import { mount } from './rio.js'; mount(document.querySelector('#rio'), { speed: 1 });
// Container: font 15px/22px "JetBrains Mono"; background #222436.

const C = { fg: '#c8d3f5', dim: '#444a73', mute: '#636da6', amber: '#ffc777', red: '#ff757f', grn: '#c3e88d', org: '#ff966c' };
export const SCENARIOS = [
  { prompt: 'add a dockerfile and compose for postgres', kw: ['dockerfile', 'compose', 'postgres'], top: ['docker-helper', 'skill'], without: "I'll write a Dockerfile and docker-compose.yml from scratch…", wo2: 'Write(Dockerfile)' },
  { prompt: 'review my diff before i push', kw: ['review', 'diff', 'push'], top: ['code-reviewer', 'agent'], without: 'Let me look at the changes…', wo2: 'Bash(git diff)' },
  { prompt: 'fix the typescript build errors in utils', kw: ['typescript', 'build', 'errors'], top: ['typescript-compiler', 'skill'], without: 'Let me check utils/…', wo2: 'Read(utils/index.ts)' },
];
const invokeOf = ([n, ty]) => ty === 'skill' ? `Skill(${n})` : ty === 'agent' ? `Task(${n})` : `SlashCommand(/${n})`;

export function renderFrame(tSeconds, opts = {}) {
  const speed = opts.speed ?? 1, S = opts.scenarios ?? SCENARIOS;
  const DUR = 10, T = tSeconds * speed, si = Math.floor(T / DUR) % S.length, t = T % DUR, sc = S[si];
  const TYPE_END = 2.4, HOOK = 2.7, SUGG = 4.4, INVOKE = 5.6, SUB = 6.4, SUB2 = 7.2, END = 9.6;
  const typed = sc.prompt.slice(0, Math.floor(Math.min(1, t / TYPE_END) * sc.prompt.length));
  const blinkOn = Math.floor(T * 2) % 2 === 0, shown = t < END, top = sc.top;
  const kwCol = (w) => sc.kw.includes(w) && t >= HOOK ? C.amber : C.fg;

  const W = 74, H = 12;
  const g = Array.from({ length: H }, () => Array.from({ length: W }, () => ({ ch: ' ', color: C.fg, op: 1 })));
  const put = (r, c, str, color, op = 1) => { for (let i = 0; i < str.length; i++) if (c + i < W && c + i >= 0 && r < H && r >= 0) g[r][c + i] = { ch: str[i], color, op }; };
  const L = 1, R = 38;
  put(0, L, 'without rio', C.mute); put(0, R, 'with rio', C.amber);
  put(1, L, '─'.repeat(35), C.dim); put(1, R, '─'.repeat(35), C.dim);
  const col = (c0, hl) => {
    put(2, c0, '>', C.mute);
    if (!shown) return 2;
    let x = c0 + 2, r = 2;
    for (const w of typed.split(' ')) { if (x + w.length > c0 + 35) { r++; x = c0 + 2; } put(r, x, w, hl ? kwCol(w) : C.fg); x += w.length + 1; }
    if (t < HOOK && blinkOn) put(r, x, '▌', C.fg);
    return r;
  };
  const rl = col(L, false), rr = col(R, true);
  if (shown && t >= INVOKE) {
    put(rl + 2, L, '●', C.org); put(rl + 2, L + 2, sc.without.slice(0, 33), C.fg);
    if (t >= SUB) { put(rl + 3, L, '●', C.org); put(rl + 3, L + 2, sc.wo2, C.fg); }
    if (t >= SUB2) put(rl + 5, L, `○ ${top[0]} ignored`, C.red);
  }
  if (shown && t >= HOOK) {
    put(rr + 2, R, '⚡', C.amber);
    put(rr + 2, R + 2, t < SUGG ? 'rio: matching' + '.'.repeat(Math.floor((t - HOOK) * 5) % 4) : `rio: SUGGESTED ${top[0]}`, t < SUGG ? C.mute : C.amber);
    if (t >= INVOKE) { put(rr + 3, R, '●', C.org); put(rr + 3, R + 2, invokeOf(top), t < INVOKE + 0.4 ? C.amber : C.fg); }
    if (t >= SUB) { put(rr + 4, R + 2, '⎿', C.dim); put(rr + 4, R + 4, `loaded ${top[1]}`, C.mute); }
    if (t >= SUB2) put(rr + 5, R, `◉ ${top[0]} invoked`, C.grn);
  }
  put(10, L, 'activation', C.mute); put(10, L + 11, '[', C.dim); put(10, L + 12, '███', C.red); put(10, L + 15, '░'.repeat(9), C.dim); put(10, L + 24, ']', C.dim); put(10, L + 26, 'sometimes', C.mute);
  put(10, R, 'activation', C.mute); put(10, R + 11, '[', C.dim); put(10, R + 12, '█'.repeat(11), C.grn); put(10, R + 23, '░', C.dim); put(10, R + 24, ']', C.dim); put(10, R + 26, 'usually', C.mute);
  put(11, L, 'illustrative — claude still makes the final call', C.dim);
  return { grid: g, scenario: si, phase: t };
}

export function mount(el, opts = {}) {
  const start = performance.now();
  const tick = (now) => {
    const { grid } = renderFrame((now - start) / 1000, opts);
    el.innerHTML = grid.map(row => '<div style="white-space:pre;height:22px">' +
      row.map(c => `<span style="color:${c.color};opacity:${c.op}">${c.ch}</span>`).join('') + '</div>').join('');
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}
