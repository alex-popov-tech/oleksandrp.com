# Handoff: claude-rio — "without / with" ASCII animation

## Overview
Animated ASCII block for the claude-rio project page in portfolio_v2. Two side-by-side
Claude Code sessions receive the same prompt; on the left Claude ignores the relevant skill
and works directly, on the right rio's UserPromptSubmit hook injects a SUGGESTED line and
the skill is invoked. Three sample prompts loop, 10 s each.

## About the design files
`Claude Rio.dc.html` is a **design reference built in HTML** (shows 3 explored options —
implement option **1c**, the third panel). Recreate it in portfolio_v2's stack. `rio.js` is a
framework-agnostic `renderFrame(t, opts)` returning a 74×12 grid of `{ch, color, op}` cells —
port that; only the rendering shell needs adapting.

## Fidelity
High-fidelity. Match glyphs, colors, timing and coordinates exactly.

## Layout
- Monospace grid 74 cols × 12 rows. JetBrains Mono 15px / 22px line-height, panel bg `#222436`.
- Two columns: left starts col 1, right starts col 38, each 35 wide.
- Row 0 headers: `without rio` mute `#636da6` / `with rio` amber `#ffc777`. Row 1: `─`×35 dim `#444a73`.
- Row 2+: `>` mute at col start, prompt text from col+2, word-wrapped inside 35 cols; typing cursor `▌`
  blinks at 2 Hz while typing. On the right column, matched keywords turn amber once the hook fires.
- Left, 2 rows below the prompt: `●` orange `#ff966c` + free-text response; next row `●` + tool call
  (`Write(Dockerfile)`); 2 rows later `○ <skill> ignored` red `#ff757f`.
- Right: `⚡` amber + `rio: matching...` (animated dots, mute) → `rio: SUGGESTED <skill>` amber;
  next row `●` + `Skill(<name>)` / `Task(<name>)` (flashes amber .4 s, then fg `#c8d3f5`);
  next row `⎿ loaded skill|agent` dim/mute; 2 rows later `◉ <skill> invoked` green `#c3e88d`.
- Row 10 bars: `activation [███░░░░░░░░░] sometimes` (red fill) / `activation [███████████░] usually` (green fill).
- Row 11: `illustrative — claude still makes the final call` dim.

## Timing (per scenario, seconds; scaled by `speed`)
0–2.4 type prompt · 2.7 hook fires (keywords highlight, "matching...") · 4.4 SUGGESTED ·
5.6 both sides respond (left free-text, right Skill call) · 6.4 second lines · 7.2 verdict lines
(ignored / invoked) · 9.6–10 blank, then next scenario.

## Scenarios
1. `add a dockerfile and compose for postgres` → kw dockerfile/compose/postgres → docker-helper (skill);
   without: "I'll write a Dockerfile and docker-compose.yml from scratch…", `Write(Dockerfile)`.
2. `review my diff before i push` → review/diff/push → code-reviewer (agent); without: "Let me look at the changes…", `Bash(git diff)`.
3. `fix the typescript build errors in utils` → typescript/build/errors → typescript-compiler (skill);
   without: "Let me check utils/…", `Read(utils/index.ts)`.

## Tokens (Tokyo Night Moon)
bg `#222436`, fg `#c8d3f5`, mute `#636da6`, dim `#444a73`, amber `#ffc777`, orange `#ff966c`,
green `#c3e88d`, red `#ff757f`. Option: speed (0.25–3).

## Files
- `rio.js` — pure `renderFrame(t, opts)` + `mount()`; `opts.scenarios` overrides the sample prompts. Port this.
- `Claude Rio.dc.html` — interactive reference; option 1c is the third panel.
