# Handoff: Acapulko ASCII data-flow animation

## Overview
Animated ASCII diagram for the acapulko project page in portfolio_v2. Shows power flowing
grid → pi5 (and grid → deye battery when charging), battery → pi5 during an outage, and
notification pulses from pi5 to Telegram and the status page (bulb on/off).
Auto-looping demo, no real data.

## About the design files
`Acapulko Flow.dc.html` is a **design reference built in HTML**, not production code.
Recreate it in portfolio_v2's stack (it renders inside the acapulko.go file view as an
embedded block). The heart of the design is `flow.js` — a framework-agnostic function
`renderFrame(t, opts)` that returns a 14×100 grid of `{ch, color, op}` cells. Port that
logic as-is; only the rendering shell (rows of spans / `<pre>`) needs to be adapted.

## Fidelity
High-fidelity. Match glyphs, colors, timing and layout exactly.

## Layout
- Monospace grid, 100 cols × 14 rows. Font: JetBrains Mono 15px, line-height 22px.
- Rendered as 14 `<div style="white-space:pre;height:22px">` rows, one `<span>` per cell
  with `color` and `opacity`. (A `<pre>` with spans per run of same color is fine.)
- Above the grid: two comment lines (`# acapulko · data flow`, `# grid or battery feeds the pi; …`)
  in `#636da6`. Below: legend line + status line with a blinking amber cursor block (9×16px, 1s steps).
- Only line-drawing / ASCII glyphs are used (`┌┐└┘│─├┤┬┴┼╘═╛ ▶◀● ▪ ◉ ○ █ ░ ⇡ ⇣ \ / _`).
  Avoid block-shading (▄▀) and emoji — they break alignment in JetBrains Mono.

## Nodes (row, col = top-left)
- **grid** pylon at (0,2): rows `   ┌┐` / ` ┌─┼┼─┐` / `─┴─┼┼─┴─` / `   ││` / `   ││` / `  ─┴┴─`.
  Amber when grid on, dim when off. Label `grid` at (1,10) fg; `~ on`/`~ off` at (3,10).
- **deye battery** at (9,1): `┌────────┐` / `│` + 8 fill cells + `├┤` / `└────────┘`;
  fill = round(pct/100·8) `█`, rest `░`; fill green when charging, blue when discharging.
  Label `deye NN%` at (12,1) mute + `⇡` (green, charging) / `⇣` (blue) at (12,10).
- **pi5** box at (5,34): `┌───┐` / `│pi5│` / `└───┘`, text `pi5` orange. LEDs at (8,34)
  power ▪ (amber/blue by source) and (8,36) activity ▪ (green when floor(T·5)%3==0 else mute).
- **telegram** paper plane at (0,57), blue: `  ________` / `  \\      /` / `   \\ \\  /` /
  `    \\ \\/` / `     \\/`. Label `telegram` at (5,59) mute.
- **bulb** at (8,57): `  ┌─┐` / ` ┌┘ └┐` / ` │   │` / ` └┐ ┌┘` / `  ├─┤` / `  ╘═╛`;
  amber when on (+ rays `╲ │ ╱` at (7,58), opacity .7), dim when off. Filament `◉`/`○` at (10,60).
  `status page` at (13,57) mute; `power on` green / `outage` red at (13,69).

## Lines
- Grid bus: (2,12..19) `─`, (2,20) `┐`, (3..5,20) `│`, (6,20) `├` (becomes `┌` when on battery).
- Bus → pi: (6,21..32) `─`, (6,33) `▶`.
- Bus ↔ battery: (7..9,20) `│`, (10,20) `└`, (10,19..13) `─`; (10,13) is `◀` amber when charging.
- pi → telegram: (5,39..47) `─`, (5,48) `┘`, (4..3,48) `│`, (2,48) `┌`, (2,49..55) `─`, (2,56) `▶`.
- pi → web: (7,39..47) `─`, (7,48) `┐`, (8..9,48) `│`, (10,48) `└`, (10,49..55) `─`, (10,56) `▶`.
- Active power path: line glyphs in source color at opacity .55, plus `●` packets every 5 cells
  marching at 7 cells/s in the flow direction (battery path reverses direction on outage).
  Inactive paths: dim `#444a73`, opacity 1.

## Timeline (loops every 16 s, scaled by `speed`)
- 0–5 s steady on grid: grid path + pi path + battery path amber; pct rises 76→88.
- 5 s grid drops: grid path dim; pi + battery paths blue (battery → bus → pi); pct falls 3.5%/s.
  Notification pulse travels both notification paths over 1.4 s (`●` head + 3-cell fading tail,
  opacities .8/.6/.4, pulse color). On arrival: plane + labels flash pulse color for .4 s,
  bulb goes off, status → `outage`, telegram bubble `[!] power outage detected` (red) shows 3.6 s.
- 11 s grid restored: amber again, pct rises from 67; pulse again; on arrival bulb on,
  status `power on`, bubble `[ok] power is back` (green).
- Bubble: box `┌─…─┐ / │ txt │ / └─…─┘` at rows 1–3 col 69, border opacity .7.
- Header phase text: `steady · on grid` / `grid dropped → notifying` / `on battery` /
  `grid restored → notifying`.

## Tokens (Tokyo Night Moon)
bg `#222436` (page `#1e2030`), fg `#c8d3f5`, mute `#636da6`, dim `#444a73`,
amber/grid `#ffc777`, blue/battery `#82aaff`, green `#c3e88d`, red `#ff757f`,
orange `#ff966c`, cyan `#86e1fc`. Options: speed (0.25–3), showLegend, gridColor, battColor, pulseColor.

## Files
- `flow.js` — pure `renderFrame(t, opts)` → `{grid, phase, gridOn, bulbOn, pct}`. Port this.
- `Acapulko Flow.dc.html` — the original interactive reference (open in a browser).
