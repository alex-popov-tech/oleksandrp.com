// Acapulko data-flow ASCII animation — pure frame renderer.
// Usage: import { mount } from './flow.js'; mount(document.querySelector('#flow'), { speed: 1 });
// Container should use font: 15px/22px "JetBrains Mono"; background #222436.

export function renderFrame(tSeconds, opts = {}) {
const P = opts;
const speed = P.speed ?? 1;
const C = { fg: '#c8d3f5', dim: '#444a73', mute: '#636da6', amber: P.gridColor ?? '#ffc777', blue: P.battColor ?? '#82aaff', red: '#ff757f', grn: '#c3e88d', cyan: '#86e1fc', org: '#ff966c', pulse: P.pulseColor ?? '#ffc777' };

const LOOP = 16, DROP = 5, RESTORE = 11, PULSE = 1.4, MSG = 3.6;
const T = tSeconds * speed, t = T % LOOP;
const gridOn = t < DROP || t >= RESTORE;
const eventT = t >= RESTORE ? t - RESTORE : t >= DROP ? t - DROP : null;
const kind = t >= RESTORE ? 'restore' : t >= DROP ? 'drop' : null;
const pulseProg = eventT !== null && eventT < PULSE ? eventT / PULSE : null;
const arrived = eventT !== null && eventT >= PULSE;
const msgOn = arrived && eventT < PULSE + MSG;
const bulbOn = t < DROP ? true : t < RESTORE ? t - DROP < PULSE : t - RESTORE >= PULSE;
const pct = t < DROP ? 76 + t * 2.4 : t < RESTORE ? 88 - (t - DROP) * 3.5 : 67 + (t - RESTORE) * 2.4;

const W = 100, H = 14;
const PLANE = ['  ________', '  \\      /', '   \\ \\  /', '    \\ \\/', '     \\/'];
const g = Array.from({ length: H }, () => Array.from({ length: W }, () => ({ ch: ' ', color: C.fg, op: 1 })));
const put = (r, c, str, color, op = 1) => { for (let i = 0; i < str.length; i++) if (c + i < W && r < H) g[r][c + i] = { ch: str[i], color, op }; };
const putLines = (r, c, lines, color, op) => lines.forEach((l, i) => put(r + i, c, l, color, op));

// ---- nodes ----
const gc = gridOn ? C.amber : C.dim;
putLines(0, 2, ['   ┌┐', ' ┌─┼┼─┐', '─┴─┼┼─┴─', '   ││', '   ││', '  ─┴┴─'], gc);
put(1, 10, 'grid', gridOn ? C.fg : C.mute); put(3, 10, gridOn ? '~ on' : '~ off', gridOn ? C.amber : C.mute);

const fill = Math.round(pct / 100 * 8), bc = gridOn ? C.dim : C.blue;
put(9, 1, '┌────────┐', C.fg);
put(10, 1, '│', C.fg); put(10, 2, '█'.repeat(fill) + '░'.repeat(8 - fill), gridOn ? C.grn : C.blue); put(10, 10, '├┤', C.fg);
put(11, 1, '└────────┘', C.fg);
put(12, 1, `deye ${Math.round(pct)}%`, C.mute); put(12, 10, gridOn ? '⇡' : '⇣', gridOn ? C.grn : C.blue);

putLines(5, 34, ['┌───┐', '│pi5│', '└───┘'], C.fg);
put(6, 35, 'pi5', C.org);
put(8, 34, '▪', gridOn ? C.amber : C.blue); put(8, 36, '▪', Math.floor(T * 5) % 3 === 0 ? C.grn : C.mute);

putLines(0, 57, PLANE, C.blue);
put(5, 59, 'telegram', C.mute); 

const bulbC = bulbOn ? C.amber : C.dim;
if (bulbOn) put(7, 58, '╲ │ ╱', C.amber, 0.7);
putLines(8, 57, ['  ┌─┐  ', ' ┌┘ └┐ ', ' │   │ ', ' └┐ ┌┘ ', '  ├─┤  ', '  ╘═╛  '], bulbC);
put(10, 60, bulbOn ? '◉' : '○', bulbC);
put(13, 57, 'status page', C.mute);

// ---- power lines ----
const gridPath = []; for (let c = 12; c <= 19; c++) gridPath.push([2, c, '─']); gridPath.push([2, 20, '┐']); for (let r = 3; r <= 5; r++) gridPath.push([r, 20, '│']); gridPath.push([6, 20, '├']);
const piPath = []; for (let c = 21; c <= 32; c++) piPath.push([6, c, '─']); piPath.push([6, 33, '▶']);
const battPath = []; for (let r = 7; r <= 9; r++) battPath.push([r, 20, '│']); battPath.push([10, 20, '└']); for (let c = 19; c >= 13; c--) battPath.push([10, c, '─']);
const flow = Math.floor(T * 7);
const drawPower = (path, color, active, reverse) => {
  const cells = reverse ? [...path].reverse() : path;
  cells.forEach(([r, c, ch], i) => {
    if (!active) { g[r][c] = { ch, color: C.dim, op: 1 }; return; }
    const hot = (i - flow) % 5 === 0 || (i - flow) % 5 === -0;
    const hot2 = ((i - flow) % 5 + 5) % 5 === 0;
    g[r][c] = hot2 ? { ch: '●', color, op: 1 } : { ch, color, op: 0.55 };
  });
};
drawPower(gridPath, C.amber, gridOn, false);
drawPower(piPath, gridOn ? C.amber : C.blue, true, false);
drawPower(battPath, gridOn ? C.amber : C.blue, true, !gridOn);
if (!gridOn) g[6][20] = { ch: '┌', color: C.blue, op: 0.55 };
if (gridOn) put(10, 13, '◀', C.amber); else put(10, 13, '─', C.blue, 0.55);

// ---- notification lines ----
const tgPath = []; for (let c = 39; c <= 47; c++) tgPath.push([5, c, '─']); tgPath.push([5, 48, '┘']); for (let r = 4; r >= 3; r--) tgPath.push([r, 48, '│']); tgPath.push([2, 48, '┌']); for (let c = 49; c <= 55; c++) tgPath.push([2, c, '─']); tgPath.push([2, 56, '▶']);
const webPath = []; for (let c = 39; c <= 47; c++) webPath.push([7, c, '─']); webPath.push([7, 48, '┐']); for (let r = 8; r <= 9; r++) webPath.push([r, 48, '│']); webPath.push([10, 48, '└']); for (let c = 49; c <= 55; c++) webPath.push([10, c, '─']); webPath.push([10, 56, '▶']);
for (const p of [tgPath, webPath]) p.forEach(([r, c, ch]) => { g[r][c] = { ch, color: C.dim, op: 1 }; });
if (pulseProg !== null) {
  for (const p of [tgPath, webPath]) {
    const i = Math.min(p.length - 1, Math.floor(pulseProg * p.length));
    for (let k = 0; k < 4 && i - k >= 0; k++) { const [r, c, ch] = p[i - k]; g[r][c] = { ch: k === 0 ? '●' : ch, color: C.pulse, op: k === 0 ? 1 : 0.8 - k * 0.2 }; }
  }
}
if (arrived && eventT < PULSE + 0.4) { putLines(0, 57, PLANE, C.pulse); put(5, 59, 'telegram', C.pulse); put(13, 57, 'status page', C.pulse); }
if (msgOn) {
  const txt = kind === 'drop' ? ' [!] power outage detected ' : ' [ok] power is back ';
  const col = kind === 'drop' ? C.red : C.grn;
  put(1, 69, '┌' + '─'.repeat(txt.length) + '┐', col, 0.7); put(2, 69, '│', col, 0.7); put(2, 70, txt, col); put(2, 70 + txt.length, '│', col, 0.7); put(3, 69, '└' + '─'.repeat(txt.length) + '┘', col, 0.7);
}
const statusTxt = bulbOn ? 'power on' : 'outage';
put(13, 69, statusTxt, bulbOn ? C.grn : C.red);

    const phase = t < DROP ? 'steady · on grid' : t < DROP + PULSE ? 'grid dropped → notifying' : t < RESTORE ? 'on battery' : t < RESTORE + PULSE ? 'grid restored → notifying' : 'steady · on grid';
return { grid: g, phase, gridOn, bulbOn, pct };
}
// Minimal renderer: container gets one <div> per row, one <span> per cell.
export function mount(el, opts = {}) {
  const start = performance.now();
  const tick = (now) => {
const { grid } = renderFrame((now - start) / 1000, opts);
el.innerHTML = grid.map(row => '<div style="white-space:pre;height:22px">' +
  row.map(c => `<span style="color:${c.color};opacity:${c.op}">${c.ch}</span>`).join('') + '</div>').join('');
requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}
