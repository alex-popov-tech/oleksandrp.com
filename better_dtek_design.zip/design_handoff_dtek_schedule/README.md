# Handoff: DTEK schedule — ASCII clock + agenda animation

## Overview
Animated ASCII block for the dtek project page in portfolio_v2: a big 7-segment-style clock
ticks through a simulated day (1 sim hour = 1 s by default) while a pointer walks the day's
compressed outage ranges (GPV group schedule: power / outage / maybe). Auto-looping demo.

## About the design files
`DTEK Schedule.dc.html` is a **design reference built in HTML** (it shows 4 explored options;
implement option **1b** only). Recreate it in portfolio_v2's stack. `schedule.js` is a
framework-agnostic `renderFrame(t, opts)` returning a 66×11 grid of `{ch, color, op}` cells —
port that logic; only the rendering shell needs adapting.

## Fidelity
High-fidelity. Match glyphs, colors, timing and coordinates exactly.

## Layout
- Monospace grid 66 cols × 11 rows. JetBrains Mono 15px / line-height 22px, panel bg `#222436`.
- Render as 11 `<div style="white-space:pre;height:22px">` rows, a `<span>` per cell (or per run).
- Only line-drawing / ASCII glyphs: `┌┐└┘│─├┤┴ ▪ ▶ ◉ ◎ ○ █ ░ ▒ [ ] –`. No emoji, no ▄▀ shading.

## Left column (cols 1–18)
- **Clock** rows 1–3, starting col 1: digits HH:MM in 3×3 glyphs, 1-col gap between glyphs, amber `#ffc777`.
  Glyph font (3 rows each):
  0 `┌─┐ │ │ └─┘`  1 ` ┐   │   ┴ `  2 `┌─┐ ┌─┘ └─┘`  3 `┌─┐  ─┤ └─┘`  4 `│ │ └─┤   │`
  5 `┌─  └─┐ └─┘`  6 `┌─  ├─┐ └─┘`  7 `┌─┐   │   │`  8 `┌─┐ ├─┤ └─┘`  9 `┌─┐ └─┤ └─┘`
  colon (1 col): row0 ` `, rows 1–2 `▪`; blinks amber/dim `#444a73` at 2 Hz (`floor(T*2)%2`).
- Row 5: `<dow> · today|tomorrow|day after` mute `#636da6`. Row 6: `GPV1.2` mute.
- Row 8: bulb `◉` (power) / `◎` (maybe) / `○` (outage) in status color + status label.
- Row 9: `next HH:MM <label>` mute. Row 10: `in 1h12m` mute.

## Agenda (rows 1–N, one row per range of the active day)
- col 22: `▶` amber on the current range, else blank.
- col 24: `HH:MM – HH:MM` (en dash). Current range: fg `#c8d3f5`; future: status color; past: dim, opacity .6.
- col 39: status glyph ×2 (`██` green `#c3e88d` power, `░░` red `#ff757f` outage, `▒▒` amber maybe); col 42: label.
- Current row only: progress `[` at col 50 (dim), 10 cells `█`/`░` amber at col 51, `]` at col 61.

## Data model
Ranges `[startHour, endHour, status]` with half-hour resolution — the same
`ScheduleRange { start, end, status: 'yes'|'no'|'maybe' }` the dtek app already compresses.
Sample today: 0–4 yes, 4–7.5 no, 7.5–8 maybe, 8–13 yes, 13–16.5 no, 16.5–17 maybe, 17–21 yes,
21–23.5 no, 23.5–24 yes. Tomorrow: 0–2 yes, 2–5.5 no, 5.5–6 maybe, 6–11 yes, 11–14.5 no,
14.5–15 maybe, 15–19 yes, 19–22.5 no, 22.5–23 maybe, 23–24 yes.

## Timing
`T = tSeconds * speed + startHour` (defaults speed 1, startHour 6); `h = T % 24`, `dayN = floor(T/24)`.
Day cycles today → tomorrow → day after (tomorrow's data) and back; dow label advances from wed.
"next" = end of current range; past midnight it points at the next day's first range.

## Tokens (Tokyo Night Moon)
bg `#222436`, fg `#c8d3f5`, mute `#636da6`, dim `#444a73`, amber `#ffc777`,
green `#c3e88d`, red `#ff757f`. Options: speed (0.25–8 h/s), startHour (0–23).

## Files
- `schedule.js` — pure `renderFrame(t, opts)` → `{grid, clock, status}` + tiny `mount()`. Port this.
- `DTEK Schedule.dc.html` — interactive reference; option 1b is the second panel.
