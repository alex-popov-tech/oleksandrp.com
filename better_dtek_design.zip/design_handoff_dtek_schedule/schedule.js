// DTEK schedule ASCII animation (option 1b) — pure frame renderer.
// Usage: import { mount } from './schedule.js'; mount(document.querySelector('#sched'), { speed: 1, startHour: 6 });
// Container: font 15px/22px "JetBrains Mono"; background #222436.

const C = { fg: '#c8d3f5', dim: '#444a73', mute: '#636da6', amber: '#ffc777', red: '#ff757f', grn: '#c3e88d' };
const ST = { yes: { ch: '█', color: C.grn, label: 'power' }, no: { ch: '░', color: C.red, label: 'outage' }, maybe: { ch: '▒', color: C.amber, label: 'maybe' } };
const DIG = { 0: ['┌─┐', '│ │', '└─┘'], 1: [' ┐ ', ' │ ', ' ┴ '], 2: ['┌─┐', '┌─┘', '└─┘'], 3: ['┌─┐', ' ─┤', '└─┘'], 4: ['│ │', '└─┤', '  │'], 5: ['┌─ ', '└─┐', '└─┘'], 6: ['┌─ ', '├─┐', '└─┘'], 7: ['┌─┐', '  │', '  │'], 8: ['┌─┐', '├─┤', '└─┘'], 9: ['┌─┐', '└─┤', '└─┘'], ':': [' ', '▪', '▪'] };
const DOW = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
export const SAMPLE = {
  today: [[0, 4, 'yes'], [4, 7.5, 'no'], [7.5, 8, 'maybe'], [8, 13, 'yes'], [13, 16.5, 'no'], [16.5, 17, 'maybe'], [17, 21, 'yes'], [21, 23.5, 'no'], [23.5, 24, 'yes']],
  tomorrow: [[0, 2, 'yes'], [2, 5.5, 'no'], [5.5, 6, 'maybe'], [6, 11, 'yes'], [11, 14.5, 'no'], [14.5, 15, 'maybe'], [15, 19, 'yes'], [19, 22.5, 'no'], [22.5, 23, 'maybe'], [23, 24, 'yes']],
};

export function renderFrame(tSeconds, opts = {}) {
  const speed = opts.speed ?? 1, startHour = opts.startHour ?? 6, group = opts.group ?? 'GPV1.2', todayDow = opts.todayDow ?? 2;
  const today = opts.today ?? SAMPLE.today, tomorrow = opts.tomorrow ?? SAMPLE.tomorrow;
  const T = tSeconds * speed + startHour, h = T % 24, dayN = Math.floor(T / 24);
  const hh = String(Math.floor(h)).padStart(2, '0'), mm = String(Math.floor((h % 1) * 60)).padStart(2, '0');
  const fmt = (x) => `${String(Math.floor(x) % 24).padStart(2, '0')}:${Math.round((x % 1) * 60) === 30 ? '30' : '00'}`;
  const dur = (x) => { const m = Math.round(x * 60); return m >= 60 ? `${Math.floor(m / 60)}h${String(m % 60).padStart(2, '0')}m` : `${m}m`; };
  const dayRanges = dayN % 3 === 0 ? today : tomorrow, nextDay = dayN % 3 === 0 ? tomorrow : today;
  const dayName = ['today', 'tomorrow', 'day after'][dayN % 3];
  const cur = dayRanges.find(([s, e]) => h >= s && h < e), curSt = ST[cur[2]];
  const nextChange = cur[1];
  const nextRange = dayRanges.find(([s]) => s === nextChange) || nextDay[0];
  const nextLabel = nextChange >= 24 ? `tomorrow ${fmt(0)} ${ST[nextDay[0][2]].label}` : `${fmt(nextChange)} ${ST[nextRange[2]].label}`;
  const bulb = cur[2] === 'yes' ? '◉' : cur[2] === 'maybe' ? '◎' : '○';

  const W = 66, H = 11;
  const g = Array.from({ length: H }, () => Array.from({ length: W }, () => ({ ch: ' ', color: C.fg, op: 1 })));
  const put = (r, c, str, color, op = 1) => { for (let i = 0; i < str.length; i++) if (c + i < W && r < H) g[r][c + i] = { ch: str[i], color, op }; };

  let cx = 1;
  for (const ch of `${hh}:${mm}`) { const d = DIG[ch]; d.forEach((l, i) => put(1 + i, cx, l, ch === ':' ? (Math.floor(T * 2) % 2 ? C.amber : C.dim) : C.amber)); cx += d[0].length + 1; }
  put(5, 1, `${DOW[(todayDow + dayN) % 7]} · ${dayName}`, C.mute); put(6, 1, group, C.mute);
  put(8, 1, bulb, curSt.color); put(8, 3, curSt.label, curSt.color);
  put(9, 1, `next ${nextLabel}`, C.mute); put(10, 1, `in ${dur(nextChange - h)}`, C.mute);
  dayRanges.forEach(([s, e, st], i) => {
    const S = ST[st], isNow = h >= s && h < e, past = h >= e;
    const col = past ? C.dim : S.color, op = past ? 0.6 : 1;
    put(1 + i, 22, isNow ? '▶' : ' ', C.amber);
    put(1 + i, 24, `${fmt(s)} – ${fmt(e)}`, isNow ? C.fg : col, op);
    put(1 + i, 39, S.ch.repeat(2), col, op); put(1 + i, 42, S.label, col, op);
    if (isNow) { const n = 10, f = Math.round((h - s) / (e - s) * n); put(1 + i, 50, '[', C.dim); put(1 + i, 51, '█'.repeat(f) + '░'.repeat(n - f), C.amber); put(1 + i, 61, ']', C.dim); }
  });
  return { grid: g, clock: `${hh}:${mm}`, status: cur[2] };
}

export function mount(el, opts = {}) {
  const start = performance.now();
  const tick = (now) => {
    const { grid } = renderFrame((now - start) / 1000, opts);
    el.innerHTML = grid.map(row => '<div style="white-space:pre;height:22px">' +
      row.map(c => `<span style="color:${c.color};opacity:${c.op}">${c.ch}</span>`).join('') + '</div>').join('');
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}
